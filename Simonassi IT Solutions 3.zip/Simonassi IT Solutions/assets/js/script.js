/// <reference path="../../typings/globals/jquery/index.d.ts" />

$(function () {

   $('#criar-conta').click(function () {
      let camposDeTexto = [$("#nome-cadastro"), $("#organizacao"), $("#cpf-cnpj"),
      $("#email-cadastro"), $("#senha-cadastro"),
      $("#endereco-cadastro"), $("#cidade-cadastro"), $("#cep-cadastro")];

      let flag = true;
      for (i = 0; i < camposDeTexto.length; i++) {
         if (!validaTextos(camposDeTexto[i]))
            flag = false;

      }

      if (validaRadios() & validaComboBox() & flag) {
         alert("Campos validados!");
      }
   });

   $('#logar').click(function () {
      let camposDeTexto = [$("#email-login"), $("#senha-login")];
      let flag = true;
      for (i = 0; i < camposDeTexto.length; i++) {
         if (!validaTextos(camposDeTexto[i]))
            flag = false;
      }
   });

   $('#enviar').click(function () {
      let camposDeTexto = [$("#nome"), $("#email"), $("#about"), $("#curriculo"), $("#endereco")];

      let flag = true;
      for (i = 0; i < camposDeTexto.length; i++) {
         if (!validaTextos(camposDeTexto[i]))
            flag = false;
      }

      if (validaCheckBoxes() && flag) {
         alert("Contratado!");
      }
   });

   $('#enviar-contato').click(function () {
      let camposDeTexto = [$("#nome-contato"), $("#form-contato"), $("#email-contato"), $("#assunto-contato"), $("#mensagem-contato")];

      let flag = true;
      for (i = 0; i < camposDeTexto.length; i++) {
         if (!validaTextos(camposDeTexto[i]))
            flag = false;
      }

      if (validaCheckBoxes() && flag) {
         alert("Mensagem enviada!");
      }
   })


   $("#like-btn-delivery").click(function () {
      let like = $("#like").data("like")
      let dislike = $("#dislike").data("dislike")

      $("#like").addClass("badge badge-secondary")
      $("#dislike").addClass("badge badge-secondary")

      $("#like").text(like)
      $("#dislike").text(dislike)
   })

   $("#like-btn-delivery").click(function () {
      let like = $("#like-delivery").data("like-delivery")
      let dislike = $("#dislike-delivery").data("dislike-delivery")

      if ($("#icon-like-delivery").hasClass("far fa-thumbs-up")) { //Botão está clicado
         $("#like-delivery").text(like + 1);
         $("#icon-like-delivery").removeClass("far fa-thumbs-up");
         $("#icon-like-delivery").addClass("fas fa-thumbs-up");

         if ($("#icon-dislike-delivery").hasClass("fas fa-thumbs-down")){ //Botão oposto
            $("#dislike-delivery").text(dislike);
            $("#icon-dislike-delivery").removeClass("fas fa-thumbs-down");
            $("#icon-dislike-delivery").addClass("far fa-thumbs-down");
         }
         return;
      }
      //Botão não está clicado
      $("#like-delivery").text(like);
      $("#icon-like-delivery").removeClass("fas fa-thumbs-up");
      $("#icon-like-delivery").addClass("far fa-thumbs-up");
      return;
   })

   $("#dislike-btn-delivery").click(function () {
      let like = $("#like-delivery").data("like-delivery")
      let dislike = $("#dislike-delivery").data("dislike-delivery")

      if ($("#icon-dislike-delivery").hasClass("far fa-thumbs-down")) { //Botão está clicado
         console.log(dislike)
         $("#dislike-delivery").text(dislike + 1);
         $("#icon-dislike-delivery").removeClass("far fa-thumbs-down");
         $("#icon-dislike-delivery").addClass("fas fa-thumbs-down");

         if ($("#icon-like-delivery").hasClass("fas fa-thumbs-up")){ //Botão oposto
            $("#like-delivery").text(like);
            $("#icon-like-delivery").removeClass("fas fa-thumbs-up");
            $("#icon-like-delivery").addClass("far fa-thumbs-up");
         }
         return;
      }
      //Botão não está clicado
      $("#dislike-delivery").text(dislike);
      $("#icon-dislike-delivery").removeClass("fas fa-thumbs-down");
      $("#icon-dislike-delivery").addClass("far fa-thumbs-down");
      return;
   })

   $("#like-btn-servico").click(function () {
      let like = $("#like-servico").data("like-servico")
      let dislike = $("#dislike-servico").data("dislike-servico")

      if ($("#icon-like-servico").hasClass("far fa-thumbs-up")) { //Botão está clicado
         $("#like-servico").text(like + 1);
         $("#icon-like-servico").removeClass("far fa-thumbs-up");
         $("#icon-like-servico").addClass("fas fa-thumbs-up");

         if ($("#icon-dislike-servico").hasClass("fas fa-thumbs-down")){ //Botão oposto
            $("#dislike-servico").text(dislike);
            $("#icon-dislike-servico").removeClass("fas fa-thumbs-down");
            $("#icon-dislike-servico").addClass("far fa-thumbs-down");
         }
         return;
      }
      //Botão não está clicado
      $("#like-servico").text(like);
      $("#icon-like-servico").removeClass("fas fa-thumbs-up");
      $("#icon-like-servico").addClass("far fa-thumbs-up");
      return;
   })


   $("#dislike-btn-servico").click(function () {
      let like = $("#like-servico").data("like-servico")
      let dislike = $("#dislike-servico").data("dislike-servico")

      if ($("#icon-dislike-servico").hasClass("far fa-thumbs-down")) { //Botão está clicado
         console.log(dislike)
         $("#dislike-servico").text(dislike + 1);
         $("#icon-dislike-servico").removeClass("far fa-thumbs-down");
         $("#icon-dislike-servico").addClass("fas fa-thumbs-down");

         if ($("#icon-like-servico").hasClass("fas fa-thumbs-up")){ //Botão oposto
            $("#like-servico").text(like);
            $("#icon-like-servico").removeClass("fas fa-thumbs-up");
            $("#icon-like-servico").addClass("far fa-thumbs-up");
         }
         return;
      }
      //Botão não está clicado
      $("#dislike-servico").text(dislike);
      $("#icon-dislike-servico").removeClass("fas fa-thumbs-down");
      $("#icon-dislike-servico").addClass("far fa-thumbs-down");
      return;
   })


   $("#like-btn-back").click(function () {
      let like = $("#like-back").data("like-back")
      let dislike = $("#dislike-back").data("dislike-back")

      if ($("#icon-like-back").hasClass("far fa-thumbs-up")) { //Botão está clicado
         $("#like-back").text(like + 1);
         $("#icon-like-back").removeClass("far fa-thumbs-up");
         $("#icon-like-back").addClass("fas fa-thumbs-up");

         if ($("#icon-dislike-back").hasClass("fas fa-thumbs-down")){ //Botão oposto
            $("#dislike-back").text(dislike);
            $("#icon-dislike-back").removeClass("fas fa-thumbs-down");
            $("#icon-dislike-back").addClass("far fa-thumbs-down");
         }
         return;
      }
      //Botão não está clicado
      $("#like-back").text(like);
      $("#icon-like-back").removeClass("fas fa-thumbs-up");
      $("#icon-like-back").addClass("far fa-thumbs-up");
      return;
   })


   $("#dislike-btn-back").click(function () {
      let like = $("#like-back").data("like-back")
      let dislike = $("#dislike-back").data("dislike-back")

      if ($("#icon-dislike-back").hasClass("far fa-thumbs-down")) { //Botão está clicado
         console.log(dislike)
         $("#dislike-back").text(dislike + 1);
         $("#icon-dislike-back").removeClass("far fa-thumbs-down");
         $("#icon-dislike-back").addClass("fas fa-thumbs-down");

         if ($("#icon-like-back").hasClass("fas fa-thumbs-up")){ //Botão oposto
            $("#like-back").text(like);
            $("#icon-like-back").removeClass("fas fa-thumbs-up");
            $("#icon-like-back").addClass("far fa-thumbs-up");
         }
         return;
      }
      //Botão não está clicado
      $("#dislike-back").text(dislike);
      $("#icon-dislike-back").removeClass("fas fa-thumbs-down");
      $("#icon-dislike-back").addClass("far fa-thumbs-down");
      return;
   })

   $("#like-btn-full").click(function () {
      let like = $("#like-full").data("like-full")
      let dislike = $("#dislike-full").data("dislike-full")

      if ($("#icon-like-full").hasClass("far fa-thumbs-up")) { //Botão está clicado
         $("#like-full").text(like + 1);
         $("#icon-like-full").removeClass("far fa-thumbs-up");
         $("#icon-like-full").addClass("fas fa-thumbs-up");

         if ($("#icon-dislike-full").hasClass("fas fa-thumbs-down")){ //Botão oposto
            $("#dislike-full").text(dislike);
            $("#icon-dislike-full").removeClass("fas fa-thumbs-down");
            $("#icon-dislike-full").addClass("far fa-thumbs-down");
         }
         return;
      }
      //Botão não está clicado
      $("#like-full").text(like);
      $("#icon-like-full").removeClass("fas fa-thumbs-up");
      $("#icon-like-full").addClass("far fa-thumbs-up");
      return;
   })


   $("#dislike-btn-full").click(function () {
      let like = $("#like-full").data("like-full")
      let dislike = $("#dislike-full").data("dislike-full")

      if ($("#icon-dislike-full").hasClass("far fa-thumbs-down")) { //Botão está clicado
         console.log(dislike)
         $("#dislike-full").text(dislike + 1);
         $("#icon-dislike-full").removeClass("far fa-thumbs-down");
         $("#icon-dislike-full").addClass("fas fa-thumbs-down");

         if ($("#icon-like-full").hasClass("fas fa-thumbs-up")){ //Botão oposto
            $("#like-full").text(like);
            $("#icon-like-full").removeClass("fas fa-thumbs-up");
            $("#icon-like-full").addClass("far fa-thumbs-up");
         }
         return;
      }
      //Botão não está clicado
      $("#dislike-full").text(dislike);
      $("#icon-dislike-full").removeClass("fas fa-thumbs-down");
      $("#icon-dislike-full").addClass("far fa-thumbs-down");
      return;
   })
})

function validaTextos(id) {
   let campoTexto = id;
   console.log(campoTexto.val())
   if (campoTexto.val() === '') {
      campoTexto.addClass("is-invalid");
      campoTexto.removeClass("is-valid");
      return false;
   }
   campoTexto.addClass("is-valid");
   campoTexto.removeClass("is-invalid");
   return true;
}

function validaRadios() {
   let pessoaFisica = $('#pessoa-fisica');
   let pessoaJuridica = $('#pessoa-juridica');

   let botoes = $("input[name='tipo-pessoa']:checked");
   if (botoes.length === 0) {
      pessoaFisica.addClass("is-invalid");
      pessoaJuridica.addClass("is-invalid");
      pessoaFisica.removeClass("is-valid");
      pessoaJuridica.removeClass("is-valid");
      $('#radio-feedback').addClass("d-block");
      return false;
   }
   pessoaFisica.addClass("is-valid");
   pessoaJuridica.addClass("is-valid");
   pessoaFisica.removeClass("is-invalid");
   pessoaJuridica.removeClass("is-invalid");
   $('#radio-feedback').removeClass("d-block");
   return true;

}

function validaComboBox() {
   let combo = $('#estado-cadastro')
   if (combo.val() === '') {
      combo.addClass('is-invalid');
      combo.removeClass('is-valid');
      return false;
   }
   combo.addClass('is-valid');
   combo.removeClass('is-invalid');
   return true;
}

function validaCheckBoxes() {
   let mobile = $('#mobile');
   let web = $('#web');
   let ui = $('#ui');
   let backend = $('#backend');

   let botoes = $('input.curriculo:checked');

   if (botoes.length === 0) {
      mobile.addClass("is-invalid");
      mobile.removeClass("is-valid");
      web.addClass("is-invalid");
      web.removeClass("is-valid");
      ui.addClass("is-invalid");
      ui.removeClass("is-valid");
      backend.addClass("is-invalid");
      backend.removeClass("is-valid");
      return false;
   }

   mobile.removeClass("is-invalid");
   mobile.addClass("is-valid");
   web.removeClass("is-invalid");
   web.addClass("is-valid");
   ui.removeClass("is-invalid");
   ui.addClass("is-valid");
   backend.removeClass("is-invalid");
   backend.addClass("is-valid");
   return true;
}

