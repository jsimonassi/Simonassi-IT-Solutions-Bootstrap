Olá, professor!
É a primeira vez que trabalho com HTML, por isso, acredito não ter construido o site da melhor forma.
Usei seu projeto como base e acrescentei alguns componentes do bootstrap como alerts, outros modelos de cards e componentes que faziam sentido no momento da criação.

Algumas dúvidas que surgiram durante a criação são as seguintes:

O navbar e o fotter são os mesmo em todo o projeto. Eu realmente preciso reescrevê-lo em cada arquivo .html?
Não existe uma forma de escrever em um lugar herdar esses componentes nos outros arquivos?

Att, João Victor Simonassi Farias.
-----------------------------------------------------------------------------------------------------------

Edit (Trabalho 2)

Dúvidas: Por que ocorre um redirect para a propria página ao tentar logar?